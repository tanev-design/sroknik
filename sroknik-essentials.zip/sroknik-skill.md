---
name: sroknik-project-context
description: Live context for the Sroknik project. Load this before making any change to the codebase to avoid duplicating existing work. Contains stack facts, design token values, copy rules, what's built, and what's missing.
---

# Sroknik — Project Context Skill

## Stack (exact versions)
- **SvelteKit 2** + **Svelte 5 Runes** (`$state`, `$derived`, `$effect`)
- **TypeScript** strict, `noUncheckedIndexedAccess`
- **Tailwind CSS v4** via `@tailwindcss/vite` — CSS-first `@theme` block in `src/app.css`
- **Bits UI v2** — Dialog (sheets), Collapsible, Accordion, etc.
- **Dexie 4** + `liveQuery` — IndexedDB only, NO localStorage, NO sessionStorage
- **date-fns v3** + **date-fns-tz** (`Europe/Sofia` timezone)
- **Lucide Svelte** — only icon library, tree-shaken
- **@vite-pwa/sveltekit** — PWA is already built and working
- **Vitest** for unit tests

## Color Tokens (from src/app.css @theme block)
| Token | Hex | Usage |
|-------|-----|-------|
| `--color-bg` | `#F9F7F4` | Page background (warm off-white) |
| `--color-surface` | `#FFFFFF` | Cards, sheets, inputs |
| `--color-border` | `#E8E4DF` | Dividers, hairlines |
| `--color-text` | `#1A1917` | Primary text |
| `--color-muted` | `#7A736B` | Secondary text, icons |
| `--color-accent` | `#1E5C3A` | Forest green — CTA, positive |
| `--color-accent-light` | `#EBF3EE` | Accent wash |
| `--color-danger` | `#B84040` | Overdue, destructive |
| `--color-danger-light` | `#F6E6E6` | Destructive confirm bg |
| `--color-warning` | `#9A6B1A` | Today urgency |
| `--color-warning-light` | `#F6ECDB` | Warning wash |

DO NOT add new color tokens without strong justification. DO NOT use hardcoded hex values in components.

## Typography
- **IBM Plex Sans** — final choice. Loaded in `app.html`. Cyrillic + Latin subsets.
- Fallback: `system-ui, sans-serif`
- Do not import other fonts. Do not change this.

## Layout Constants
- Max width: 960px, centered
- Mobile padding: 16px · Desktop: 32px
- Card padding: 16px mobile · 20px desktop
- Card radius: `--radius-card: 14px`
- Control radius: `--radius-control: 10px`
- Min touch target: 44×44px (enforced)
- BottomNav: 56px + `env(safe-area-inset-bottom)`, hidden ≥768px

## Urgency System (4 levels, not 3)
| Level | Condition | Color | Left strip |
|-------|-----------|-------|-----------|
| `overdue` | days < 0 | `--color-danger` | danger |
| `today` | days === 0 | `--color-warning` | warning |
| `soon` | 1–14 days | `--color-accent` | accent |
| `later` | >14 days | `--color-border` | border |

The number 14 is the threshold for "soon". Not 30, not 90. This is deliberate.

## Architecture Rules
- Never access `db.*` from `.svelte` components — always go through a repository in `src/lib/db/repositories/`
- Stores use `liveQuery` + repositories, expose read-only getters
- All data writes are async functions on repositories or `$lib/db/backup.ts`
- All Bulgarian strings are in `src/lib/copy/bg.ts`. Components must never hard-code Bulgarian text.
- SSR is globally disabled — IndexedDB doesn't exist server-side

## What Is Already Built (MVP complete per PRODUCT.md)
✅ Днес view (overdue / today / soon / later grouping)  
✅ Срокове list + filters: all / active / completed / archived  
✅ Add / edit / complete / archive / delete deadlines  
✅ 11 categories: винетка · ГО · ТП · лична карта · паспорт · шофьорска · ток · вода · интернет · местен данък · друг  
✅ Cars (name + plate + owner), 1 car free  
✅ Document sets linked to a person, 1 set free  
✅ ICS export (single deadline + all)  
✅ JSON export + import (replace or merge)  
✅ "Delete all data" with typed ИЗТРИЙ confirmation  
✅ 3-step onboarding (dismissible)  
✅ PWA + offline page at /offline  
✅ Browser notifications (opt-in from /settings)  
✅ /plus page with feature comparison + "Скоро"  
✅ Privacy strings in Settings  
✅ `pluralDays()` and `pluralMonths()` in bg.ts  
✅ BottomNav (Днес · Срокове · Документи · Още)  
✅ TopBar, AddDeadlineSheet, DeadlineDetailSheet, EmptyState  
✅ PlanLimitNotice (inline, non-blocking, never a modal)  
✅ OfficialLinkButton component  

## What Is NOT Yet Built (target improvements)
❌ Dots SVG on documents card — needs to be **deleted**  
❌ EUR currency support (primary) with BGN secondary until 8 август 2026  
❌ Per-category expandable contextual info panels (fees, penalties, what to bring)  
❌ "Как работи" page/section with data flow infographic + timelines + fee tables  
❌ GitHub transparency links beyond what's in /plus  
❌ `DATA_LAST_VERIFIED` constant for sourced official data  

## Copy Rules (from COPY_BG.md — abbreviated)
- ти form always, never Вие
- No exclamation marks ever
- No emoji anywhere
- No English loan words when a Bulgarian equivalent exists
- No marketing superlatives (революционно, магически, ултра, etc.)
- One line preferred — if it doesn't fit on one line, question if it belongs in UI
- "Напомняния" not "уведомления" / "нотификации"
- "Данните са само на това устройство." — exact privacy string
- Run every string through: "Does a calm, competent friend say this out loud?"

## Currency (from January 2026)
Bulgaria adopted EUR on 1 January 2026. Fixed rate: 1.95583 BGN = 1 EUR.  
Dual display period: 1 January 2026 → 8 август 2026.  
After 8 август: EUR only.  
EUR is always the primary/larger display. BGN in parentheses during dual period.  
Use `formatFee(euroAmount, bgnAmount)` from `src/lib/utils/currency.ts`.

## Key Bulgarian Document Facts
| Document | Validity | Renewal deadline | Penalty |
|----------|----------|-----------------|---------|
| Лична карта | 4/10/безсрочна г. | 30 дни след изтичане | 10.23–76.69 € |
| Паспорт | 5 г. (стандарт) / 1 г. (временен) | — | 10.23–76.69 € ако не върнеш в 3 месеца |
| Шофьорска (A/B) | 10 г. | —  | 5.11–102.26 € за управление с изтекла |
| Шофьорска (C/D) | 5 г. | — | same |
| ТП | Varies (1–4 г.) | — | 25.57–51.13 € |
| ГО | Annual | — | heavy |
| Паспорт air travel | — | airlines require ≥6 months validity | — |

## Design Prohibitions (from DESIGN.md)
- No glassmorphism, no neumorphism, no blur-heavy surfaces
- No gradient heroes, no neon, no "AI glow" effects
- No modals for limit enforcement (aggressive upsell pattern)
- No hamburger menus or nested settings trees
- No lorem ipsum — all onboarding copy is localized
- No illustrations — empty states use dashed border only
- Urgency comes ONLY from the 4px DeadlineCard strip — no additional color washes
